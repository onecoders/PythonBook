from distutils.core import setup

setup(
        name          = 'silicon_nester',
        version       = '1.1.0',
        py_modules    = ['nester'],
        author        = 'silicon',
        author_email  = 'onecoders@gmail.com',
        url           = 'http://www.baidu.com',
        description   = 'A simple printer of nested lists',
    )

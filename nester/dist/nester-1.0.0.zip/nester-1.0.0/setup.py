from distutils.core import setup

setup(
        name          = 'nester',
        version       = '1.0.0',
        py_modules    = ['nester'],
        author        = 'silicon',
        author_email  = 'onecoders@gmail.com',
        url           = 'http://www.baidu.com',
        description   = 'A simple printer of nested lists',
    )
